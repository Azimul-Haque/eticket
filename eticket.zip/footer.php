<div class="footer">
    <div class="container">
	    <hr>
	    <p class="text-muted text-center">&copy; <?php echo date('Y'); ?> Copyright Reserved, E-Ticket.Com</p>
	</div>
</div>


</body>
</html>