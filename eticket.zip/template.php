

<?php 
    require("session.php");
    include('menu.php'); 
?>

<div class="container" style="margin-top:70px">
  	<div class="row">
  		<div class="col-md-12">
  			<h3>Header</h3>
			<p>The .navbar-right class is used to right-align navigation bar buttons.</p>
  		</div>
  	</div>
</div>


<?php include('footer.php'); ?>